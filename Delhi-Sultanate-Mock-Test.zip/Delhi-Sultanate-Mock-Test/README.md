\# Delhi Sultanate Mock Test



This is a basic mock test landing page for Delhi Sultanate quizzes.



\## How to Use



1\. Open `index.html` in a browser.

2\. Click "Start Test" to begin.



