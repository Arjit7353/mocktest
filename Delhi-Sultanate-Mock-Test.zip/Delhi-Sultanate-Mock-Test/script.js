function startTest() {
  alert("Test will begin shortly...");
}
