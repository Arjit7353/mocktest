export default function Home() {
  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>Welcome to your Mock Test Platform</h1>
      <p>Deployed on Vercel</p>
    </div>
  )
}